# CRYPTOLIVE Telegram Bot

🚀 Railway-ready Telegram bot with crypto conversion, alerts, and live prices.

## 📦 How to Deploy on Railway

1. Fork or upload this project to your GitHub
2. Go to [Railway](https://railway.app), create a **New Project**
3. Choose **Deploy from GitHub**
4. Set the environment variables in Railway:
   - `TOKEN` — your bot token from @BotFather
   - `CHAT_ID` — your Telegram user/chat ID (or leave empty if bot is public)
5. Set Start Command:
   ```bash
   python bot.py
   ```

6. Done 🎉 Your bot is running 24/7.

## ✅ Features
- Inline crypto conversion with menu
- Multi-step conversion: select coin → amount → target
- Auto updates via CoinGecko

---

Made for CRYPTOLIVE 🔥
